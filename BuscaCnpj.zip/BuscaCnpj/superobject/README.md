# delphi7-json-parser-superobject
Delphi 7 JSON SuperObject compatible version. Derived from this link :

[SuperObject b0b774bd784a1ac6146003b200d3bb67811beebb](https://github.com/hgourvest/superobject/tree/b0b774bd784a1ac6146003b200d3bb67811beebb)

